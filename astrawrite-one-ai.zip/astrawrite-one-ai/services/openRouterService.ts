import { ArticleConfig } from '../types';

export const callOpenRouter = async (prompt: string, model: string = "google/gemini-2.0-flash-exp:free", systemInstruction?: string) => {
    const apiKey = localStorage.getItem('astrawrite_active_key');
    if (!apiKey) throw new Error("No API Key found for OpenRouter");

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${apiKey}`,
            "HTTP-Referer": "https://astrawrite.ai", // Optional
            "X-Title": "AstraWrite One AI", // Optional
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            "model": model,
            "messages": [
                ...(systemInstruction ? [{ "role": "system", "content": systemInstruction }] : []),
                { "role": "user", "content": prompt }
            ]
        })
    });

    const data = await response.json();
    if (data.error) throw new Error(data.error.message || "OpenRouter Error");
    return data.choices?.[0]?.message?.content || "";
};

// Mirroring the Gemini Service functions for OpenRouter support
export const openRouterGenerateTitle = async (kw: string) => {
    return callOpenRouter(`Suggest 5 click-worthy, SEO-optimized titles for "${kw}". Return only the best one.`, "google/gemini-2.0-flash-exp:free");
};

export const openRouterGenerateSEOAnalysis = async (c: string, k?: string) => {
    const res = await callOpenRouter(
        `Analyze this content for keyword "${k}". Provide: 1. Score (0-100), 2. Readability, 3. Keyword Density, 4. Actionable Tips, 5. Missing Keywords.`,
        "google/gemini-2.0-flash-exp:free",
        `You are an expert SEO auditor. Return ONLY JSON format: { "score": number, "readabilityLevel": string, "keywordDensity": string, "actionableTips": string[], "missingKeywords": string[] }`
    );
    try { return JSON.parse(res); } catch { return { score: 70, readabilityLevel: 'High School', keywordDensity: '0.8%', actionableTips: [], missingKeywords: [] }; }
};
