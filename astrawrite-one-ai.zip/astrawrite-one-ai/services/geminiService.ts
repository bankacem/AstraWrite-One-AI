import { GoogleGenAI, GenerateContentResponse, Type, Modality } from "@google/genai";
import { ArticleConfig, KeywordMetrics, BrandVoice, ResearchData, AiProvider } from '../types';

const getActiveConfig = () => {
  const key = localStorage.getItem('astrawrite_active_key') || process.env.VITE_GEMINI_API_KEY || "";
  const provider = (localStorage.getItem('astrawrite_active_provider') || AiProvider.GEMINI) as AiProvider;
  return { key, provider };
};

const getAi = () => {
  const { key } = getActiveConfig();
  return new GoogleGenAI({ apiKey: key });
};

const callOpenRouter = async (prompt: string, model: string = "google/gemini-2.0-flash-exp:free", systemInstruction?: string, tools?: any[]) => {
  const { key } = getActiveConfig();
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${key}`,
      "HTTP-Referer": "https://astrawrite.ai",
      "X-Title": "AstraWrite One AI",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      "model": model,
      "messages": [
        ...(systemInstruction ? [{ "role": "system", "content": systemInstruction }] : []),
        { "role": "user", "content": prompt }
      ],
      ...(tools ? { "tools": tools } : {})
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message || "OpenRouter Error");
  return data.choices?.[0]?.message?.content || "";
};

export const uploadToImgBB = async (base64Data: string): Promise<string> => {
  const apiKey = "3cf6b9ebf33c1dd64a270c5c25a15a05";
  try {
    const base64Image = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
    const formData = new FormData();
    formData.append("image", base64Image);
    const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
      method: "POST",
      body: formData,
    });
    const result = await response.json();
    if (result.success) return result.data.url;
    throw new Error("Upload failed");
  } catch (error) {
    console.error("ImgBB Error:", error);
    return base64Data;
  }
};

export const generateImage = async (prompt: string, aspectRatio: string): Promise<string> => {
  const ai = getAi();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: `Professional, high-quality digital art for a blog: ${prompt}. Cinematic lighting, detailed.` }] },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio as any
      }
    },
  });

  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  if (part?.inlineData) {
    const url = await uploadToImgBB(`data:image/png;base64,${part.inlineData.data}`);
    return url;
  }
  throw new Error("Failed to generate image");
};

export const generateBlogImages = async (title: string, style: string): Promise<string[]> => {
  if (style === 'None') return [];
  try {
    const url = await generateImage(`Hero image for article: "${title}". Style: ${style}`, "16:9");
    return [url];
  } catch {
    return [];
  }
};

export const generateArticleStream = async (config: ArticleConfig, onChunk: (chunk: string) => void) => {
  const { provider, key } = getActiveConfig();

  const systemInstruction = `You are an elite SEO Content Engineer. 
  Your goal is to write a "Masterpiece" article that ranks #1.
  Follow these rules:
  - Language: ${config.language}
  - Tone: ${config.tone}
  - Style: ${config.humanize ? 'Human-like, bypass AI detectors, vary sentence length, use occasional idioms.' : 'Professional and informative.'}
  - Formatting: Use semantic HTML (h2, h3, p, strong, blockquote, table).
  - Structure: ${config.includeTableOfContents ? 'Include TOC.' : ''} ${config.includeKeyTakeaways ? 'Include Key Takeaways.' : ''}
  - Data: ${config.connectToWeb ? 'Use current 2024/2025 statistics and trends.' : 'Use evergreen knowledge.'}
  - Length: Aim for ${config.articleSize === 'Large' ? '3000+' : config.articleSize === 'Medium' ? '2000' : '1200'} words.`;

  const prompt = `Write a comprehensive guide about "${config.mainKeyword}". 
  Title: ${config.title}
  Include sections on: ${config.detailsToInclude || 'the core concepts, benefits, and future outlook.'}
  ${config.includeFAQ ? 'End with a detailed FAQ section.' : ''}
  ${config.includeTables ? 'Include at least one comparison table.' : ''}
  Required Keywords to use: ${config.keywordsToInclude}`;

  if (provider === AiProvider.OPENROUTER) {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        "model": "google/gemini-2.0-flash-exp:free",
        "messages": [
          { "role": "system", "content": systemInstruction },
          { "role": "user", "content": prompt }
        ],
        "stream": true
      })
    });

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data.trim() === '[DONE]') break;
            try {
              const json = JSON.parse(data);
              const content = json.choices?.[0]?.delta?.content || "";
              onChunk(content);
            } catch (e) { }
          }
        }
      }
    }
    return;
  }

  const ai = getAi();
  const response = await ai.models.generateContentStream({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction,
      tools: config.connectToWeb ? [{ googleSearch: {} }] : undefined,
    }
  });

  for await (const chunk of response) {
    onChunk(chunk.text || "");
  }
};

export const continueWriting = async (text: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    return callOpenRouter(`Continue the following text naturally: ${text}`, "google/gemini-2.0-flash-exp:free");
  }
  const ai = getAi();
  const res = await ai.models.generateContent({ model: 'gemini-3-pro-preview', contents: `Continue this: ${text}` });
  return res.text || "";
};

export const generateTitle = async (kw: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    return callOpenRouter(`Suggest 5 click-worthy, SEO-optimized titles for "${kw}". Return only the best one.`, "google/gemini-2.0-flash-exp:free");
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Suggest 5 click-worthy, SEO-optimized titles for "${kw}". Return only the best one.`
  });
  return res.text?.replace(/"/g, '').trim() || kw;
};

export const rewriteContent = async (t: string, m: string, l: string = 'English (US)') => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    return callOpenRouter(`Rewrite this content. Mode: ${m}. Language: ${l}. Text: \n\n${t}`, "google/gemini-2.0-flash-exp:free");
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Rewrite this content. Mode: ${m}. Language: ${l}. Text: \n\n${t}`
  });
  return res.text || t;
};

export const generateSEOAnalysis = async (c: string, k?: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Analyze this content for keyword "${k}". Provide: 1. Score (0-100), 2. Readability, 3. Keyword Density, 4. Actionable Tips, 5. Missing Keywords.`,
      "google/gemini-2.0-flash-exp:free",
      `You are an expert SEO auditor. Return ONLY JSON: { "score": number, "readabilityLevel": string, "keywordDensity": string, "actionableTips": string[], "missingKeywords": string[] }`
    );
    try { return JSON.parse(res); } catch { return { score: 75, readabilityLevel: 'High School', keywordDensity: '1.2%', actionableTips: [], missingKeywords: [] }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      systemInstruction: `You are an expert SEO auditor. Analyze the provided content against the target keyword "${k}". Provide a quantitative and qualitative analysis in JSON format.`
    },
    contents: `Analyze this content for keyword "${k}". 
    Provide:
    1. Score (0-100) based on on-page SEO best practices.
    2. Readability Level (e.g., High School, University).
    3. Keyword Density (percentage).
    4. Actionable Tips (3-5 specific improvements).
    5. Missing Keywords (top 5-8 related terms to include).
    
    Content: ${c}`
  });
  try {
    return JSON.parse(res.text || '{}');
  } catch {
    return { score: 75, readabilityLevel: 'High School', keywordDensity: '1.2%', actionableTips: ['Use more headers', 'Add internal links'], missingKeywords: [] };
  }
};

export const humanizeContent = async (t: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    return callOpenRouter(`Rewrite the following text to perfectly mimic human writing. Use varying sentence lengths, transition words, and remove all 'AI-sounding' phrases. Text:\n\n${t}`, "google/gemini-2.0-flash-exp:free");
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Rewrite the following text to perfectly mimic human writing. Use varying sentence lengths, transition words, and remove all 'AI-sounding' phrases. Goal: 100% human score.\n\n${t}`
  });
  return res.text || t;
};

export const analyzeBrandVoice = async (t: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Analyze the writing style of this text. Identify Archetype, Tone, and provide a System Instruction for future writing. Return as JSON. Text:\n\n${t}`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "archetype": string, "tone": string, "systemInstruction": string }`
    );
    try { return { id: Date.now().toString(), ...JSON.parse(res) }; } catch { return { id: '1', name: 'Standard Voice', archetype: 'Professional', systemInstruction: 'Write professionally.' }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: { responseMimeType: 'application/json' },
    contents: `Analyze the writing style of this text. Identify Archetype, Tone, and provide a System Instruction for future writing. Return as JSON.`
  });
  try {
    return { id: Date.now().toString(), ...JSON.parse(res.text || '{}') };
  } catch {
    return { id: '1', name: 'Standard Voice', archetype: 'Professional', systemInstruction: 'Write professionally.' };
  }
};

export const generateFAQAnswers = async (q: string[]) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Provide expert answers for these questions: ${q.join(', ')}.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON as an array: [ { "question": string, "answer": string } ]`
    );
    try { return JSON.parse(res); } catch { return q.map(question => ({ question, answer: "Answer pending..." })); }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: { responseMimeType: 'application/json' },
    contents: `Provide expert answers for these questions: ${q.join(', ')}. Return as JSON array of {question, answer}.`
  });
  try {
    return JSON.parse(res.text || '[]');
  } catch {
    return q.map(question => ({ question, answer: "Answer pending..." }));
  }
};

export const generateKeywordMetrics = async (k: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Analyze the keyword "${k}". Provide: 1. Search Volume, 2. Difficulty (0-100), 3. CPC, 4. Competition, 5. Intent.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "volume": string, "difficulty": number, "cpc": string, "competition": string, "intent": string }`
    );
    try {
      const data = JSON.parse(res);
      return {
        volume: data.volume || 'N/A',
        difficulty: data.difficulty || 50,
        cpc: data.cpc || '$0.00',
        competition: data.competition || 'Medium',
        intent: data.intent || 'Informational'
      };
    } catch { return { volume: 'N/A', difficulty: 50, cpc: '$0.00', competition: 'Medium', intent: 'Informational' }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are a specialized SEO analytics engine. Use search data to provide accurate metrics for keywords."
    },
    contents: `Analyze the keyword "${k}". 
    Provide:
    1. Search Volume (estimated monthly searches, e.g., '10K', '500').
    2. Difficulty (0-100 score).
    3. CPC (estimated cost per click in USD).
    4. Competition (Low, Medium, High).
    5. Intent (Informational, Navigational, Transactional, Commercial).
    
    Return ONLY JSON.`
  });
  try {
    const data = JSON.parse(res.text || '{}');
    return {
      volume: data.volume || 'N/A',
      difficulty: data.difficulty || 50,
      cpc: data.cpc || '$0.00',
      competition: data.competition || 'Medium',
      intent: data.intent || 'Informational'
    };
  } catch {
    return { volume: 'N/A', difficulty: 50, cpc: '$0.00', competition: 'Medium', intent: 'Informational' };
  }
};

export const performDeepKeywordResearch = async (k: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Perform deep keyword research for "${k}". Find 10-15 related keywords and 5-8 PAA questions.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "keywords": [ { "term", "volume", "difficulty", "cpc", "competition" } ], "questions": [ string ] }`
    );
    try { return JSON.parse(res); } catch { return { keywords: [], questions: [] }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are an advanced Ahrefs/Semrush-style keyword researcher. Find real semantic keywords and user questions."
    },
    contents: `Perform deep keyword research for "${k}".
    Provide:
    1. A list of 10-15 related/LSI keywords with their metrics (term, volume, difficulty, cpc, competition).
    2. A list of 5-8 'People Also Ask' style questions.
    
    Return as JSON: { "keywords": [...], "questions": [...] }`
  });
  try {
    return JSON.parse(res.text || '{ "keywords": [], "questions": [] }');
  } catch {
    return { keywords: [], questions: [] };
  }
};

export const generateTopicCluster = async (t: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Create a topic cluster for "${t}". Main Pillar + 5-7 Clusters.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "pillarPage": { "title", "keyword" }, "clusters": [ { "title", "keyword", "linkToPillarAnchor" } ] }`
    );
    try { return JSON.parse(res); } catch { return { pillarPage: { title: `Guide to ${t}`, keyword: t }, clusters: [] }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are an SEO Content Strategist. Design a pillar-cluster architecture."
    },
    contents: `Create a topic cluster for "${t}".
    Identify one main Pillar Page and 5-7 Cluster Pages that support it.
    Return as JSON: { "pillarPage": { "title", "keyword" }, "clusters": [{ "title", "keyword", "linkToPillarAnchor", "crossLinkSuggestion" }] }`
  });
  try {
    return JSON.parse(res.text || '{}');
  } catch {
    return { pillarPage: { title: `Guide to ${t}`, keyword: t }, clusters: [] };
  }
};

export const analyzeSuperPageStructure = async (k: string, u?: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Analyze SERP winners for "${k}". Design a 'Super Page' structure.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "winningTitle": string, "structure": [ { "level", "text" } ], "hook": string, "wordCount": string }`
    );
    try { return JSON.parse(res); } catch { return { winningTitle: `Mastering ${k}`, structure: [], hook: '', wordCount: '2500' }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are a conversion optimization expert and SEO lead."
    },
    contents: `Analyze the SERP for "${k}". Look at top winners. 
    Design a 'Super Page' that combines the best elements of all top results.
    Provide structure (H2/H3/Intent), estimated word count, winning title, conversion points, and a unique 'hook'.
    Return ONLY JSON.`
  });
  try {
    return JSON.parse(res.text || '{}');
  } catch {
    return { winningTitle: `Mastering ${k}`, structure: [], hook: '', wordCount: '2500', conversionPoints: [] };
  }
};

export const analyzeCompetitors = async (k: string, c?: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Search for "${k}". Compare top 3 winners to "${c}".`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON: { "avgWordCount": number, "avgImageCount": number, "commonKeywords": string[], "missingTopics": string[], "topCompetitors": [ { "title", "url" } ] }`
    );
    try { return JSON.parse(res); } catch { return { avgWordCount: 0, avgImageCount: 0, commonKeywords: [], missingTopics: [], actionableAdvice: '', topCompetitors: [] }; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are an SEO Competitive Intelligence Agent. Analyze real search results."
    },
    contents: `Search for "${k}". Analyze the top 3-5 ranking pages.
    Compare them to the user's provided content concept: "${c}".
    Provide:
    1. Average word count of top results.
    2. Average image count.
    3. Common keywords they all share.
    4. Topics they cover that the user is missing.
    5. Specific actionable advice to beat them.
    6. List of top competitors (title and URL).
    
    Return ONLY JSON.`
  });
  try {
    return JSON.parse(res.text || '{}');
  } catch {
    return { avgWordCount: 0, avgImageCount: 0, commonKeywords: [], missingTopics: [], actionableAdvice: '', topCompetitors: [] };
  }
};

export const generateSeoGuidelines = async (kw: string) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Top 10 LSI keywords for "${kw}" with target counts.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON as array: [ { "term": string, "targetCount": number } ]`
    );
    try { return JSON.parse(res); } catch { return [{ term: kw, targetCount: 3 }]; }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are an SEO Content Optimizer."
    },
    contents: `Find the top 8-12 LSI/Semantic keywords that should be included in an article about "${kw}" to rank #1.
    For each keyword, provide a recommended 'targetCount' (e.g. 2, 5, 0).
    Return ONLY as a JSON array: [ { "term": "keyword", "targetCount": 3 }, ... ]`
  });
  try {
    return JSON.parse(res.text || '[]');
  } catch {
    return [{ term: kw, targetCount: 3 }];
  }
};

export const generateBulkKeywordMetrics = async (k: string[]) => {
  const { provider } = getActiveConfig();
  if (provider === AiProvider.OPENROUTER) {
    const res = await callOpenRouter(
      `Analyze keywords: ${k.join(', ')}. Provide metrics.`,
      "google/gemini-2.0-flash-exp:free",
      `Return ONLY JSON array: [ { "term", "volume", "difficulty", "cpc", "competition" } ]`
    );
    try { return JSON.parse(res); } catch { return k.map(t => ({ term: t, volume: 'N/A', difficulty: 50, cpc: '$0.00', competition: 'Medium' })); }
  }
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    config: {
      responseMimeType: 'application/json',
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are a bulk keyword analyzer."
    },
    contents: `Analyze this list of keywords: ${k.join(', ')}.
    Provide metrics (term, volume, difficulty, cpc, competition) for each.
    Return ONLY as a JSON array of objects.`
  });
  try {
    return JSON.parse(res.text || '[]');
  } catch {
    return k.map(t => ({ term: t, volume: 'N/A', difficulty: 50, cpc: '$0.00', competition: 'Medium' }));
  }
};
